#!/bin/sh

chmod +x /usr/local/directadmin/scripts/directadmind
/usr/local/directadmin/scripts/directadmind lic

exit 0;
