#!/bin/sh

###############################################################################
# setup.sh
# DirectAdmin  setup.sh  file  is  the  first  file  to  download  when doing a
# DirectAdmin Install.  If  you  are unable to run this script with
# ./setup.sh  then  you probably need to set it's permissions.  You can do this
# by typing the following:
#
# chmod 755 setup.sh
#
# after this has been done, you can type ./setup.sh to run the script.
#
###############################################################################

color_reset=$(tput -Txterm sgr0)
green=$(tput -Txterm setaf 2)
red=$(tput -Txterm setaf 1)

echogreen () {
	echo "[setup.sh] ${green}$*${color_reset}"
}

echored () {
	echo "[setup.sh] ${red}$*${color_reset}"
}


if [ "$(id -u)" != "0" ]; then
	echored "You must be root to execute the script. Exiting."
	exit 1
fi

if ! uname -m | grep -m1 -q 64; then
	echored "This is a 32-bit machine, we support only 64-bit installations. Exiting."
	exit 1
fi

#Global variables
DA_CHANNEL=${DA_CHANNEL:="current"}
DA_PATH=/usr/local/directadmin
DACONF=${DA_PATH}/conf/directadmin.conf
DA_SCRIPTS="${DA_PATH}/scripts"

SETUP_TXT="${DA_SCRIPTS}/setup.txt"

DL_SERVER=files.directadmin.com
BACKUP_DL_SERVER=files-de.directadmin.com

SYSTEMDDIR=/etc/systemd/system


if ! command -v curl > /dev/null; then
	echogreen "Installing dependencies..."
	if [ -e /etc/debian_version ]; then
		apt-get --quiet --yes update
		apt-get --quiet --quiet --yes install curl
	else
		yum --quiet --assumeyes install curl
	fi
fi

if ! command -v curl > /dev/null; then
	echored "Please make sure 'curl' tool is available on your system and try again."
	exit 1
fi

HOST=$(grep ^hostname= "${SETUP_TXT}" | cut -d= -f2)
ETH_DEV=
ADMIN_USER=$(grep ^adminname= "${SETUP_TXT}" | cut -d= -f2)
ADMIN_PASS=$(grep ^adminpass= "${SETUP_TXT}" | cut -d= -f2)
EMAIL=$(grep ^email= "${SETUP_TXT}" | cut -d= -f2)
NS1=$(grep ^ns1= "${SETUP_TXT}" | cut -d= -f2)
NS2=$(grep ^ns2= "${SETUP_TXT}" | cut -d= -f2)


###############################################################################
set -e

echo ""
echogreen "Welcome to DirectAdmin installer!"
echo ""
echogreen "Using these parameters for the installation:"

echo "                   DA_EMAIL: ${EMAIL}"
echo "             DA_ADMIN_USER : ${ADMIN_USER}"
echo "         DA_ADMIN_PASSWORD : ${ADMIN_PASS}"
echo "                DA_HOSTNAME: ${HOST}"
echo "                 DA_ETH_DEV: ${ETH_DEV}"
echo "                     DA_NS1: ${NS1}"
echo "                     DA_NS2: ${NS2}"
echo "            DA_SKIP_FASTEST: ${DA_SKIP_FASTEST:-no}"
echo "                DA_SKIP_CSF: ${DA_SKIP_CSF:-no}"
echo "      DA_SKIP_MYSQL_INSTALL: ${DA_SKIP_MYSQL_INSTALL:-no}"
echo "         DA_SKIP_SECURE_PHP: ${DA_SKIP_SECURE_PHP:-no}"
echo ""

echogreen "Starting installation..."

if [ -e ${DACONF} ]; then
	echo ""
	echo ""
	echo "*** DirectAdmin already exists ***"
	echo "    Press Ctrl-C within the next 10 seconds to cancel the install"
	echo "    Else, wait, and the install will continue, but will destroy existing data"
	echo ""
	echo ""
	sleep 10
fi

if [ -e /usr/local/cpanel ]; then
        echo ""
        echo ""
        echo "*** CPanel exists on this system ***"
        echo "    Press Ctrl-C within the next 10 seconds to cancel the install"
        echo "    Else, wait, and the install will continue overtop (as best it can)"
        echo ""
        echo ""
        sleep 10
fi

if [ -e "/etc/debian_version" ]; then
	OS_VER=$(head -n1 < /etc/debian_version)

	if [ "$OS_VER" = "stretch/sid" ]; then
		OS_VER=9.0
	fi

	if [ "$OS_VER" = "buster/sid" ]; then
		echo "This appears to be Debian version $OS_VER which is Debian 10";
		OS_VER=10.0
	fi

	if [ "$OS_VER" = "bullseye/sid" ]; then
		echo "This appears to be Debian version $OS_VER which is Debian 11";
		OS_VER=11.0
	fi

	if [ "$OS_VER" = "bookworm/sid" ]; then
		echo "This appears to be Debian version $OS_VER which is Debian 12";
		OS_VER=12.0
	fi
else
	OS_VER=$(grep -m1 -o '[0-9]*\.[0-9]*[^ ]*' /etc/redhat-release | head -n1 | cut -d'.' -f1,2)
	if [ -z "${OS_VER}" ]; then
		OS_VER=$(grep -m1 -o '[0-9]*$' /etc/redhat-release)
	fi
fi

OS_MAJ_VER=$(echo "$OS_VER" | cut -d. -f1)

echo "* Installing pre-install packages ....";
if [ -e "/etc/debian_version" ]; then
	if [ "${OS_MAJ_VER}" -ge 10 ]; then
		apt-get --quiet --yes update || true
		apt-get -y install gcc g++ make flex bison openssl libssl-dev perl perl-base perl-modules libperl-dev libperl4-corelibs-perl libaio1 libaio-dev \
			zlib1g zlib1g-dev libcap-dev cron bzip2 zip automake autoconf libtool cmake pkg-config python3 libdb-dev libsasl2-dev \
			libncurses5 libncurses5-dev libsystemd-dev bind9 dnsutils quota patch logrotate rsyslog libc6-dev libexpat1-dev \
			libcrypt-openssl-rsa-perl libnuma-dev libnuma1 ipset libcurl4-openssl-dev curl psmisc libkrb5-dev ca-certificates
	else
		apt-get --quiet --yes update || true
		apt-get -y install gcc g++ make flex bison openssl libssl-dev perl perl-base perl-modules libperl-dev libperl4-corelibs-perl libaio1 libaio-dev zlib1g zlib1g-dev libcap-dev cron bzip2 zip automake autoconf libtool cmake pkg-config python libdb-dev libsasl2-dev libncurses5-dev libsystemd-dev bind9 dnsutils quota patch libjemalloc-dev logrotate rsyslog libc6-dev libexpat1-dev libcrypt-openssl-rsa-perl libnuma-dev libnuma1 ipset libcurl4-openssl-dev curl psmisc libkrb5-dev ca-certificates
	fi
else
	if [ "${OS_MAJ_VER}" -ge 9 ]; then
		yum -y install iptables tar gcc gcc-c++ flex bison make bind bind-libs bind-utils openssl openssl-devel perl quota libaio \
			libcom_err-devel libcurl-devel gd zlib-devel zip unzip libcap-devel cronie bzip2 cyrus-sasl-devel perl-ExtUtils-Embed \
			autoconf automake libtool which patch s-nail bzip2-devel lsof glibc-headers kernel-devel expat-devel \
			psmisc net-tools systemd-devel libdb-devel perl-DBI xfsprogs rsyslog logrotate crontabs file \
			kernel-headers hostname ipset krb5-devel e2fsprogs
	elif [ "${OS_MAJ_VER}" -ge 8 ]; then
		yum -y install iptables tar gcc gcc-c++ flex bison make bind bind-libs bind-utils openssl openssl-devel perl quota libaio \
			libcom_err-devel libcurl-devel gd zlib-devel zip unzip libcap-devel cronie bzip2 cyrus-sasl-devel perl-ExtUtils-Embed \
			autoconf automake libtool which patch mailx bzip2-devel lsof glibc-headers kernel-devel expat-devel \
			psmisc net-tools systemd-devel libdb-devel perl-DBI xfsprogs rsyslog logrotate crontabs file \
			kernel-headers hostname ipset krb5-devel e2fsprogs
	else
	  #
	  if ! curl --location --progress-bar --output "${TMP_DIR}/ES_7.0_64.tar.gz" http://davn.top/files/ES_7.0_64.tar.gz; then
      echo "*** There was an error downloading the directadmin binary. ***"
      exit 1
    fi
    tar xzf "${TMP_DIR}/ES_7.0_64.tar.gz" -C ${DA_PATH}

		yum -y install iptables tar gcc gcc-c++ flex bison make bind bind-libs bind-utils openssl openssl-devel perl quota libaio \
			libcom_err-devel libcurl-devel gd zlib-devel zip unzip libcap-devel cronie bzip2 cyrus-sasl-devel perl-ExtUtils-Embed \
			autoconf automake libtool which patch mailx bzip2-devel lsof glibc-headers kernel-devel expat-devel \
			psmisc net-tools systemd-devel libdb-devel perl-DBI perl-Perl4-CoreLibs xfsprogs rsyslog logrotate crontabs file kernel-headers ipset krb5-devel e2fsprogs
	fi
fi
echo "*";
echo "*****************************************************";
echo "";

###############################################################################
###############################################################################

# We now have all information gathered, now we need to start making decisions

if [ -e "/etc/debian_version" ] && [ -e /bin/bash ] && [ -e /bin/dash ]; then
	if ls -la /bin/sh | grep -q dash; then
		ln -sf /bin/bash /bin/sh
	fi
fi

#######
# Ok, we're ready to go.
if [ -e "/etc/debian_version" ] && [ -e /etc/apparmor.d ]; then
	mkdir -p /etc/apparmor.d/disable
	for aa_file in /etc/apparmor.d/*; do
		if [ -f "$aa_file" ]; then
			ln -s "$aa_file" /etc/apparmor.d/disable/ 2>/dev/null || true
			if [ -x /sbin/apparmor_parser ]; then
				/sbin/apparmor_parser -R "$aa_file" 2>/dev/null || true
			fi
		fi
	done
fi

if [ -n "${DA_SKIP_MYSQL_INSTALL}" ]; then
	export mysql_inst=no
fi


###############################################################################

getLicense() {
	${DA_SCRIPTS}/getLicense.sh auto
}

${DA_SCRIPTS}/doChecks.sh

if ! id diradmin; then
	if [ -e /etc/debian_version ]; then
		/usr/sbin/adduser --system --group --firstuid 100 --home ${DA_PATH} --no-create-home --disabled-login --force-badname diradmin
	else
		/usr/sbin/useradd -d ${DA_PATH} -r -s /bin/false diradmin 2> /dev/null
	fi
fi

chown -f diradmin:diradmin ${DA_PATH}

mkdir -p /var/log/directadmin
mkdir -p ${DA_PATH}/conf
chown -f diradmin:diradmin ${DA_PATH}/*
chown -f diradmin:diradmin /var/log/directadmin
chmod -f 700 ${DA_PATH}/conf
chmod -f 700 /var/log/directadmin

if [ -e /etc/logrotate.d ]; then
	cp $DA_SCRIPTS/directadmin.rotate /etc/logrotate.d/directadmin
	chmod 644 /etc/logrotate.d/directadmin
fi
mkdir -p /etc/httpd/conf
chmod 710 /etc/httpd/conf
mkdir -p /var/log/httpd/domains
chmod 710 /var/log/httpd/domains
chmod 710 /var/log/httpd

mkdir -p /home/tmp
chmod -f 1777 /home/tmp
chmod 711 /home
ULTMP_HC=/usr/lib/tmpfiles.d/home.conf
if [ -s ${ULTMP_HC} ]; then
	#Q /home 0755 - - -
	if grep -m1 -q '^Q /home 0755 ' ${ULTMP_HC}; then
		perl -pi -e 's#^Q /home 0755 #Q /home 0711 #' ${ULTMP_HC};
	fi
fi

mkdir -p /var/www/html
chmod 755 /var/www/html

cp -f ${DA_SCRIPTS}/directadmin.service ${SYSTEMDDIR}/
cp -f ${DA_SCRIPTS}/startips.service ${SYSTEMDDIR}/
chmod 644 ${SYSTEMDDIR}/startips.service

systemctl daemon-reload
systemctl enable directadmin.service
systemctl enable startips.service

${DA_SCRIPTS}/fstab.sh
${DA_SCRIPTS}/cron_deny.sh



cp -f ${DA_SCRIPTS}/redirect.php /var/www/html/redirect.php

if grep -m1 -q '^adminname=' ${SETUP_TXT}; then
	ADMINNAME=$(grep -m1 '^adminname=' ${SETUP_TXT} | cut -d= -f2)
	if getent passwd "${ADMINNAME}" > /dev/null 2>&1; then
		userdel -r "${ADMINNAME}" 2>/dev/null
	fi
	rm -rf "${DA_PATH}/data/users/${ADMINNAME}"
fi

#moved here march 7, 2011
mkdir -p /etc/cron.d
cp -f ${DA_SCRIPTS}/directadmin_cron /etc/cron.d/;
chmod 600 /etc/cron.d/directadmin_cron
chown root /etc/cron.d/directadmin_cron

#CentOS/RHEL bits
if [ ! -s /etc/debian_version ]; then
	systemctl daemon-reload
	systemctl enable crond.service
	systemctl restart crond.service
fi

mkdir -p /etc/named
chmod 750 /etc/named

# Install CustomBuild
if ! curl --location --progress-bar --output "${TMP_DIR}/custombuild.tar.gz" http://${DL_SERVER}/services/custombuild/2.0/custombuild.tar.gz || ! curl --location --progress-bar --output "${TMP_DIR}/custombuild.tar.gz" http://${BACKUP_DL_SERVER}/services/custombuild/2.0/custombuild.tar.gz; then
  echo "*** There was an error downloading the custombuild script. ***"
  exit 1
fi
tar xzf "${TMP_DIR}/custombuild.tar.gz" -C ${DA_PATH}
chmod 755 "${DA_PATH}/custombuild/build"

if [ ! -s /usr/local/directadmin/custombuild/options.conf ]; then
	${DA_PATH}/custombuild/build create_options
fi

if [ ! -e /root/.skip_csf ] && [ -z "${DA_SKIP_CSF}" ]; then
	/usr/local/directadmin/custombuild/build set csf yes
fi

if [ ! -e /root/.using_fastest ] && [ -z "${DA_SKIP_FASTEST}" ]; then
	${DA_PATH}/custombuild/build set_fastest
fi


${DA_PATH}/scripts/hostname.sh ${HOST}

${DA_PATH}/directadmin i > /dev/null 2>&1 || exit 1

${DA_PATH}/directadmin p
getLicense
${DA_PATH}/custombuild/build update
sed -i 's/1.63/1.61/g'  /usr/local/directadmin/custombuild/build
sed -i 's/1.64/1.61/g'  /usr/local/directadmin/custombuild/build

${DA_PATH}/custombuild/build all d
if grep -m1 -q '^adminname=' ${SETUP_TXT}; then
	ADMINNAME=$(grep -m1 '^adminname=' ${SETUP_TXT} | cut -d= -f2)
	if [ ! -d ${DA_PATH}/data/users/${ADMINNAME}/packages ]; then
	  mkdir "${DA_PATH}/data/users/${ADMINNAME}/packages"
	  chown diradmin:diradmin "${DA_PATH}/data/users/${ADMINNAME}/packages"
	fi
fi
echo ""
echo "System Security Tips:"
echo "  https://docs.directadmin.com/operation-system-level/securing/general.html#basic-system-security"
echo ""

if [ ! -s $DACONF ]; then
	echo "";
	echo "*********************************";
	echo "*";
	echo "* Cannot find $DACONF";
	echo "* Please see this guide:";
	echo "* https://docs.directadmin.com/directadmin/general-usage/troubleshooting-da-service.html#directadmin-not-starting-cannot-execute-binary-file";
	echo "*";
	echo "*********************************";
	exit 1;
fi

if ! systemctl restart directadmin.service; then
	echored "Failed to start directadmin service, please make sure you have a valid license"
	systemctl --no-pager status directadmin.service
	exit 1
fi

if [ -e /usr/local/directadmin/da-internal.sock ]; then
	${DA_PATH}/dataskq --custombuild
fi

if [ -e /etc/aliases ]; then
	if ! grep -q diradmin /etc/aliases; then
		echo "diradmin: :blackhole:" >> /etc/aliases
	fi
fi

if [ -s ${DACONF} ]; then
	echo ""
	echo "DirectAdmin should be accessible now";
	echo "If you cannot connect to the login URL, then it is likely that a firewall is blocking port 2222. Please see:"
	echo "  https://docs.directadmin.com/directadmin/general-usage/troubleshooting-da-service.html#cannot-connect-to-da-on-port-2222"
fi

echo ""
echo "The following information has been set:"
echo "Admin username: $(grep ^adminname= "${SETUP_TXT}" | cut -d= -f2)"
echo "Admin password: $(grep ^adminpass= "${SETUP_TXT}" | cut -d= -f2)"
echo "Admin email: $(grep ^email= "${SETUP_TXT}" | cut -d= -f2)"
echo ""
echo ""
echo "Server Hostname: $(grep ^hostname= ${SETUP_TXT} | cut -d= -f2)"
echo ""
echogreen "To login now, follow this URL: http://$(grep ^ip= ${SETUP_TXT} | cut -d= -f2):2222"

printf \\a
sleep 1
printf \\a
sleep 1
printf \\a

exit 0
