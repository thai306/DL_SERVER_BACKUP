#!/bin/sh

DA_PATH=/usr/local/directadmin
DA_SCRIPTS=${DA_PATH}/scripts
DA_TQ=${DA_PATH}/data/task.queue

DA_SYSTEMD_SERVICE=/etc/systemd/system/directadmin.service
if [ -s ${DA_SYSTEMD_SERVICE} ] && ! diff --brief ${DA_SCRIPTS}/directadmin.service ${DA_SYSTEMD_SERVICE} > /dev/null; then
	cp -f ${DA_SCRIPTS}/directadmin.service ${DA_SYSTEMD_SERVICE}
	systemctl daemon-reload
fi

if ! diff --brief ${DA_SCRIPTS}/directadmin_cron /etc/cron.d/directadmin_cron > /dev/null; then
	cp -f ${DA_SCRIPTS}/directadmin_cron /etc/cron.d/directadmin_cron
	chmod 600 /etc/cron.d/directadmin_cron
	chown root /etc/cron.d/directadmin_cron
fi

if [ -e /etc/logrotate.d ] && ! diff --brief ${DA_SCRIPTS}/directadmin.rotate /etc/logrotate.d/directadmin > /dev/null; then
	cp $DA_SCRIPTS/directadmin.rotate /etc/logrotate.d/directadmin
	chmod 644 /etc/logrotate.d/directadmin
fi

#Set permissions with current DA version.
${DA_PATH}/directadmin p

{
	echo "action=cache&value=showallusers"
	echo "action=cache&value=safemode"
	echo "action=convert&value=cronbackups"
	echo "action=convert&value=suspendedmysql"
	echo "action=syscheck"

	#https://www.directadmin.com/features.php?id=1930
	echo "action=da-popb4smtp&value=restart"

	# Do we really need them?
	#DA 1.56.2
	#https://www.directadmin.com/features.php?id=2332
	echo 'action=rewrite&value=cron_path'
} >> $DA_TQ

#Allow all TCP/UDP outbound connections from root
if [ -e /etc/csf/csf.allow ] && [ -x /usr/sbin/csf ]; then
	if ! grep -q 'out|u=0' /etc/csf/csf.allow; then
		/usr/sbin/csf -a "tcp|out|u=0" "Added by DirectAdmin"
		/usr/sbin/csf -a "udp|out|u=0" "Added by DirectAdmin"
	fi
fi

# DA 1.63.5 remove directadmin from services.status list
SERVICES_STATUS=${DA_PATH}/data/admin/services.status
if [ -s ${SERVICES_STATUS} ] && grep -q '^directadmin=' ${SERVICES_STATUS}; then
	sed -i '/^directadmin=/d' ${SERVICES_STATUS}
fi

# DA 1.63.9 use log cli arguments in init.d script
DA_INITD_SERVICE=/etc/init.d/directadmin
if [ -s ${DA_INITD_SERVICE} ] && grep -q 'PROGBIN="/usr/local/directadmin/directadmin d"' ${DA_INITD_SERVICE}; then
	sed -i 's|PROGBIN="/usr/local/directadmin/directadmin d"|PROGBIN="/usr/local/directadmin/directadmin server --daemonize"|' ${DA_INITD_SERVICE}
fi

DA_INITD_FREEBSD=/usr/local/etc/rc.d/directadmin
if [ -s ${DA_INITD_FREEBSD} ] && grep -q 'command_args="d"' ${DA_INITD_FREEBSD}; then
	sed -i 's|command_args="d"|command_args="server --daemonize"|' ${DA_INITD_FREEBSD}
fi

# DA 1.641 remove old system DB file
if [ -s /usr/local/directadmin/data/admin/da.db ]; then
	rm -f /usr/local/directadmin/data/admin/da.db
fi
